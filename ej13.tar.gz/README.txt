registro_usuario.php realiza la parte A del ejercicio.

clientes.php realiza la segunda parte del ejercicio.

Todas las funciones están en php/funciones.php

En la carpeta html se encuentran los archivos planos '.html' incluidos en el ejercicio.

Utilizo el sistema de conexión mediante PDO y POO del ejercicio 14 con un JSON externo.
